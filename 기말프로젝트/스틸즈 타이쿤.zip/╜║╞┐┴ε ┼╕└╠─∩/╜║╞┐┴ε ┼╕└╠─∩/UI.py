import gfw_image
import Game
import gfw
import os
import World




class UIS:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = gfw.gfw_image.load("res/UI.png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def update(self):
        pass