
import gfw_image
import Game
import gfw
import os
import World




class Fose:
    def __init__(self):
        self.x = 145
        self.y = 260
        self.ly= 220
        self.image = gfw.gfw_image.load("res/난이도 4.png")
        self.ima = gfw.gfw_image.load("res/난이도 4.png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def draws(self):
        self.image.draw(self.x, self.ly)
    def update(self):
        pass
