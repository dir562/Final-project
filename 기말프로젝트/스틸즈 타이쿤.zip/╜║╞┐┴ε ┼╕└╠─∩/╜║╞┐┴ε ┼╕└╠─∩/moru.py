from pico2d import*
import os
import Game
import gfw_image
import gfw



class morus:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.fram = 1
        morus.images = None
        if morus.images == None:
            morus.images = gfw_image.load("res/모루.png")
    def update(self):
        pass
    def draw(self):
        self.images.draw(self.x, self.y)
        self.update()

  


