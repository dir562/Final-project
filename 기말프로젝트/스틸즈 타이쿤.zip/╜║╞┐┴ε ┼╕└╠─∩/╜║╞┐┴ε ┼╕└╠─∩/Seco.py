
import gfw_image
import Game
import gfw
import os
import World




class twos:
    def __init__(self):
        self.x = 145
        self.y = 260
        self.ly =220
        self.image = gfw.gfw_image.load("res/난이도 2.png")
        self.ima = gfw.gfw_image.load("res/난이도 2.png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def draws(self):
        self.image.draw(self.x, self.y-40)
    def draws(self):
        self.ima.draw(self.x, self.ly)
    def update(self):
        pass

