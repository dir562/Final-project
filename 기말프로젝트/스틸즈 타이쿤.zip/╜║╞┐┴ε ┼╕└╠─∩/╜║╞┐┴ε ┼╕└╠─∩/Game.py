import gfw
from pico2d import *
import Title
import World
import gobj
import font
import Start
import gold
import choice
from Weapon import Weapons
from moru import morus
from map import maps
from UI import UIS
from gold import moneys
from menuchang import ME
from interface import inter
from content import MA
from sel import MAd
from tool_up import Uper
from Bow import Arrows
from Axe import Ax
from F import fishing
from moru_up1 import morus1
from moru_up2 import morus2
from Mate import Yes


Ja1 = True
Ja2 = False
Ja3 = False

Upg = False



open_menu = False # 업그레이드 1(골드벌이)
select = False  # 컨텐츠 선택창
oepn = False
select_m = False
tools = False
earn_gold = 30

gob = 0.1
level = 1
use_gold = 200
running = True
metrial1 = True
up_stack = 1
up_stack1 = 1
up_stack2 = 1

ups =0
interface_draw1 = False
interface_draw2 = False
interface_draw3 = False




canvas_width = 400
canvas_height = 350

def enter():
    gfw.World.init(['Material','mor2','mor1','moruss', 'Weapons', 'ui', 'UID', 'SP', 'mbox', 'mbox2', 'to', 'AAr', 'Fish', 'Wood', 'internets'])
   


    global Mas
    Mas = Yes()
    gfw.World.add(gfw.layer.Material, Mas)

    global Weap
    Weap = Weapons()
 
    global Gold
    Gold = moneys(700, 500)

    global up_menu
    up_menu = UIS()
    gfw.World.add(gfw.layer.UID, up_menu)

    global SL # 컨텐츠 
    SL = ME()
    gfw.World.add(gfw.layer.SP, SL)

    global tooll
    tooll = Uper()
    gfw.World.add(gfw.layer.to, tooll)

    global Aro
    Aro = Arrows()
    gfw.World.add(gfw.layer.AAr, Aro)

    global Fosh
    Fosh = fishing()
    gfw.World.add(gfw.layer.Fish, Fosh)

    global Aox
    Aox = Ax()
    gfw.World.add(gfw.layer.Wood, Aox)

    global int
    int = inter()
    gfw.World.add(gfw.layer.internets, int)

    if(select_m==True):
        global mod # 메뉴 박스
        mod = MAd()
        gfw.World.add(gfw.layer.mbox2, mod)
    elif(select_m==False):
        global mos # 메뉴 박스
        mos = MA()
        gfw.World.add(gfw.layer.mbox, mos)
    

    
    global Mo
    Mo = morus()
    gfw.World.add(gfw.layer.moruss, Mo)


    global Mo1
    Mo1 = morus1()
    gfw.World.add(gfw.layer.mor1, Mo1)


    global Mo2
    Mo2 = morus2()
    gfw.World.add(gfw.layer.mor2, Mo2)

    global font
    font = gfw.font.load('res/a아띠.ttf', 20)





    global flip_wav, flip_wav2
    global flips, clicks
    flip_wav = load_wav(('res/코인소리.wav'))
    
    flip_wav2 = load_wav(('res/비프음.wav'))
    flips = load_wav(('res/itemdestroy.wav'))
    clicks = load_wav(('res/button-28.wav'))

  




def check_enemy(e):
    if gobj.collides_box(player, e):
        print('Player Collision', e)
        e.remove()
        return


def update():
    gfw.World.update()



def draw():
    # gobj.draw_collision_box()
    if(Ja1 == True):
        Mo.draw()
    elif(Ja1 == False and Ja2 == True):
        Mo1.draw()
    elif(Ja2==False and Ja3 == True):
        Mo2.draw()


    if(Upg == True):
        Mas.draw()


    font.draw(20, 575, 'Gold: %d' % Gold.don)
    font.draw(450, 575, 'touch cost : %d'%earn_gold)
    mos.draw() 
    

    if(Upg ==True):
       if(Ja2==False and Ja3==False):
          font.draw(350, 190, "골드 : %d"%Mo1.cost)
          font.draw(350, 315, "적용 x")
          font.draw(350, 235, "물가, 능력치: %d"%Mo1.upgra)
       elif(Ja2==True):
          font.draw(350, 190, "골드 : %d"%Mo2.cost)
          font.draw(350, 315, "물가, 능력치: %d"%Mo1.upgra)
          font.draw(350, 235, "물가, 능력치: %d"%Mo2.upgra)
       elif(Ja3==True):
           font.draw(350, 315, "물가, 능력치: %d"%Mo2.upgra)
           font.draw(350, 235, "업데이트 예정")

    if(open_menu == True):
        up_menu.draw()
        font.draw(410, 225, "%d"%use_gold)
        font.draw(270, 195, "level : %d"%level)
    elif(select == True):
        SL.draw()
    elif(tools == True):
        tooll.draw()
        int.draw()
        if(interface_draw1 == True):
          font.draw(400, 215, "%d"%Aro.Power)
          font.draw(400, 185, "%d"%Aro.upgrade_cost)
        elif(interface_draw2 == True):
          font.draw(400, 215, "%d"%Aox.Power)
          font.draw(400, 185, "%d"%Aox.upgrade_cost)
        elif(interface_draw3 == True):
          font.draw(400, 215, "%d"%Fosh.Power)
          font.draw(400, 185, "%d"%Fosh.upgrade_cost)


    Weap.draw()



    


def handle_event(e):
    # prev_dx = boy.dx
    global Weap
    global use_gold
    global gob
    global level
    global earn_gold
    global open_menu
    global select
    global open
    global tools
    global Aro
    global Aox
    global Fosh
    global up_stack
    global up_stack1
    global up_stack2
    global int
    global interface_draw1
    global interface_draw2
    global interface_draw3
    global Ja1
    global Ja2
    global Ja3
    global Mate
    global moru_up1
    global moru_up2
    global Upg
    global ups

    Weap.handle_events()

    if e.type == SDL_QUIT:
        gfw.quit()
    elif e.type == SDL_KEYDOWN:
        if e.key == SDLK_ESCAPE:
            open = False
            select = False
            tools = False
            Upg = False
        if e.key == SDLK_UP:
            clicks.play()
            if open_menu == False:
                open_menu = True
                open = True
            elif open_menu == True:
                open_menu = False
                open = False
    elif e.type == SDL_MOUSEMOTION:
            if(tools == True):
                if(190<Weap.x<230 and 110<Weap.y<135):
                   if(interface_draw1==False):
                      interface_draw1 = True
                      interface_draw2 = False
                      interface_draw3 = False
                if(365<Weap.x<405 and 110<Weap.y<135):
                   if(interface_draw2==False):
                      interface_draw2 =True
                      interface_draw1 = False
                      interface_draw3 = False
                if(540<Weap.x<580 and 110<Weap.y<135):
                   if(interface_draw3==False):
                      interface_draw2 = False
                      interface_draw1 = False
                      interface_draw3 = True
    elif e.type == SDL_MOUSEBUTTONDOWN:
        if e.button == SDL_BUTTON_LEFT:
            if(open == False):
                if(141<Weap.x<655 and 0<Weap.y<320):
                   flip_wav.play()
                   Gold.don +=earn_gold
            elif(open_menu == True):
                if(300<Weap.y<417 and 282<Weap.x<409):
                   if Gold.don>=use_gold:
                      flips.play()
                      Gold.don -= use_gold
                      level = level + 1
                      use_gold = use_gold +(use_gold*gob)+(1*level)
                      earn_gold = earn_gold + (earn_gold*0.207)
                   if(level == 10):
                      use_gold = use_gold +(use_gold*0.31)
                      gob = 0.16
                   elif (level == 40):
                      use_gold = use_gold + use_gold*0.45
                      gob = 0.24
                   elif Gold.don<use_gold:
                      print("돈이", str((use_gold-Gold.don)),"원 모자라는 군")
                      flip_wav2.play()
            if(705<Weap.x<795 and 550<Weap.y<590):
                clicks.play()
                if(select==False):
                    select =True
                    open = True
                elif(select == True):
                    select = False
                    open = False

            if(select == True):
               if(530<Weap.x<590 and 116<Weap.y<143):
                  clicks.play()
                  select = False
                  open = False
               if(300<Weap.x<600 and 300<Weap.y<350):
                   gfw.push(choice)
                   select = False
                   clicks.play()
               if(300<Weap.x<600 and 380<Weap.y<430):
                   tools = True
                   select = False
                   clicks.play()
               if(300<Weap.x<600 and 220<Weap.y<270):
                   Upg = True
                   select = False
                   clicks.play()


            if(Upg == True):
                if(500<Weap.x<515 and 410<Weap.y<430):
                    Upg = False
                    clicks.play()
                if(Ja2 ==False and Ja3 == False):
                  if(310<Weap.x<360 and 175<Weap.y<200):
                     if(Mo1.cost<Gold.don):
                        Ja2 =True
                        Ja1 =False
                        Gold.don = Gold.don - Mo1.cost
                        ups = Mo1.upgrader
                        Aox.Power *= ups
                        Aro.Power *= ups
                        Fosh.Power *= ups
                        earn_gold *= ups
                        up_stack *= ups
                        up_stack1 *= ups
                        up_stack2 *= ups
                     elif(Mo1.cost>Gold.don):
                        print("골드 부족")
                elif(Ja2==True):
                    if(310<Weap.x<360 and 175<Weap.y<200):
                       if(Mo2.cost<Gold.don):
                          Ja3 =True
                          Ja2 =False
                          Gold.don -= Mo2.cost
                          ups = Mo2.upgrader
                          Aox.Power *= ups
                          Aro.Power *= ups
                          Fosh.Power *= ups
                          earn_gold *= ups
                          up_stack *= ups
                          up_stack1 *= ups
                          up_stack2 *= ups
                       elif(Mo2.cost>Gold.don):
                           print("골드 부족")
            if(tools == True):
                if(631<Weap.x<656 and 440<Weap.y<463):
                    tools = False
                    clicks.play()
                if(190<Weap.x<230 and 110<Weap.y<135):
                    if(Gold.don>Aro.upgrade_cost):
                       Aro.level +=1
                       Aro.Power = Aro.Power+up_stack
                       Aro.upgrade_cost = Aro.upgrade_cost + ((Aro.upgrade_cost/20)+(up_stack*4))
                       Gold.don -=Aro.upgrade_cost
                       Aro.update()
                       flips.play()
                    elif(Gold.don<Aro.upgrade_cost):
                        print("강화 비용이 모자릅니다")
                    if(Aro.level%10 ==0):
                        up_stack = up_stack*1.8
                        Aro.Power = Aro.Power*1.8
                        Aro.upgrade_cost *=1.8
                if(365<Weap.x<405 and 110<Weap.y<135):
                    if(Gold.don>Aox.upgrade_cost):
                       Aox.level +=1
                       Aox.Power = Aox.Power+up_stack1
                       Aox.upgrade_cost = Aox.upgrade_cost + ((Aox.upgrade_cost/20)+(up_stack1*4))
                       Gold.don -=Aox.upgrade_cost
                       flips.play()
                    elif(Gold.don<Aox.upgrade_cost):
                        print("강화 비용이 모자릅니다")
                    if(Aox.level%10 ==0):
                        up_stack1 = up_stack1*1.8
                        Aox.Power = Aox.Power*1.8
                        Aox.upgrade_cost *=1.8
                if(540<Weap.x<580 and 110<Weap.y<135):
                    if(Gold.don>Fosh.upgrade_cost):
                       Fosh.level +=1
                       Fosh.Power = Fosh.Power+up_stack2
                       Fosh.upgrade_cost = Fosh.upgrade_cost + ((Fosh.upgrade_cost/20)+(up_stack2*4))
                       Gold.don -=Fosh.upgrade_cost
                       flips.play()
                    elif(Gold.don<Fosh.upgrade_cost):
                        print("강화 비용이 모자릅니다")
                    if(Fosh.level%10 ==0):
                        up_stack1 = up_stack1*1.8
                        Fosh.Power = Aox.Power*1.8
                        Fosh.upgrade_cost *=1.8








            
def pause():
    pass
def resume():
    pass


def exit():
    pass

if __name__ == '__main__':
    gfw.run_main()
