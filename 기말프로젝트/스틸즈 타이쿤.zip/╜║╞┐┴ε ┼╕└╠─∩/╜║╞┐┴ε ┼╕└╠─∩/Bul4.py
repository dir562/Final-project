



from pico2d import*
import os
import Game
import gfw_image
import gfw
import Title
from gold import moneys
import random
from moru import morus


Chajip = False



height = 600
width = 800

def enter():
    global Gold
    Gold = moneys()
    Gold.init()

class glass4:
    def __init__(self):
        self.lucky = (random.randint(1,100))
        self.lx = 400
        self.ly =190
        self.x = 400
        self.y = 470
        self.frame =2
        self.hp = 300000
        self.get_gold = 50000
        self.reduce = 30    
        self.count = 0
        self.defence = 700
        self.dx =1
        self.times = 60 
        self.fride = 180
        glass4.images = None
        if glass4.images == None:
            glass4.images = gfw_image.load("res/벌목4.png")
        glass4.ima = None
        if glass4.ima ==None:
            glass4.ima = gfw_image.load("res/벌목4-1.png")
    def update(self):
        if(self.x>800):
            self.dx =-1
        elif(self.x<0):
            self.dx = 1
        pass
    def draw(self):
        self.images.draw(self.x, self.y)

        self.ima.draw(self.lx, self.ly)
        self.update()
    def handle_events(self):
        global Gold
        global running
        hide_cursor()
        events = get_events()
        for event in events:
           if event.type == SDL_MOUSEMOTION:
              self.x,self.y = event.x,height - 1 -event.y
           if event.type == SDL_MOUSEBUTTONDOWN:
               if event.button == SDL_BUTTON_LEFT:
                   pass
           if event.type == SDL_MOUSEBUTTONUP:
               if event.button == SDL_BUTTON_LEFT:
                   pass


    
 
