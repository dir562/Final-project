
import gfw_image
import Game
import gfw
import os
import World




class MAd:
    def __init__(self):
        self.x = 750
        self.y = 570
        self.contach = gfw.gfw_image.load("res/메뉴(8040)2.png")
    def draw_c(self):
        self.contach.draw(self.x, self.y)
    def update(self):
        pass

    