import gfw
from pico2d import *
import Title
import World
import gobj
import Game
import font
import Start
import gold
import huntSpace
from Weapon import Weapons
from moru import morus
from map import maps
from UI import UIS
from gold import moneys
from menuchang import ME
from content import MA
from sel import MAd
import Gang

open_menu = False # 업그레이드 1(골드벌이)
select = False  # 컨텐츠 선택창
oepn = False
select_m = False
earn_gold = 30

gob = 0.1
level = 1
use_gold = 200
running = True



canvas_width = 400
canvas_height = 350

def enter():
    gfw.World.init(['moruss', 'Weapons', 'ui', 'UID', 'SP', 'mbox', 'mbox2'])
    global Weap
    Weap = Weapons()
 
    global Gold
    Gold = moneys(700, 500)

    global up_menu
    up_menu = UIS()
    gfw.World.add(gfw.layer.UID, up_menu)

    global SL # 컨텐츠 
    SL = ME()
    gfw.World.add(gfw.layer.SP, SL)

    global image
    image = load_image('res/선택화면.png')

    global clicks
    clicks = load_wav(('res/button-28.wav'))

    global bg_musics
    bg_musics = load_music(('res/320. Go Spring Outing.mp3'))
    bg_musics.set_volume(55)
    bg_musics.repeat_play()

    

    



    




def check_enemy(e):
    if gobj.collides_box(player, e):
        print('Player Collision', e)
        e.remove()
        return


def update():
    gfw.World.update()



def draw():
    # gobj.draw_collision_box()
    image.draw(400, 300)
    Weap.draw()

    




def handle_event(e):
    global Weap
    Weap.handle_events()

    if e.type == SDL_QUIT:
        gfw.quit()
    elif (e.type, e.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
        gfw.quit()
    if(e.type, e.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
        if(690<Weap.x<780 and 530<Weap.y<570):
            clicks.play()
            gfw.change(Game)
            global bg_music
            bg_music = load_music(('res/428. 변명의 변명.mp3'))
            bg_music.set_volume(55)
            bg_music.repeat_play()
        if(590<Weap.x<690 and 420<Weap.y<520):
           gfw.change(huntSpace)
           clicks.play()
        if(200<Weap.x<290 and 250<Weap.y<330):
            gfw.change(Gang)
            clicks.play()

def exit():
    global image
    del image


    
if __name__ == '__main__':
    gfw.run_main()

def pause():
    pass
def resume():
    pass