import gfw_image
import Game
import gfw
import os
import World



class MA:
    def __init__(self):
        self.x = 750
        self.y = 570
        self.image = gfw.gfw_image.load("res/메뉴(8040).png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def update(self):
        pass

    