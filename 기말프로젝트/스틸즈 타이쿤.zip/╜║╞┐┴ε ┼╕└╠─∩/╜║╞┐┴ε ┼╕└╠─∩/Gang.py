
import gfw
from pico2d import *
import Title
import random
import World
import gobj
import font
import Start
import gold
import choice
import Game
from Weapon import Weapons
from moru import morus
from map import maps
from UI import UIS
from gold import moneys
from menuchang import ME
from interface import inter
from content import MA
from sel import MAd
from tool_up import Uper
from Axe import Ax
from F import fishing
from moru_up1 import morus1
from moru_up2 import morus2
from Mate import Yes
from Bow import Arrows
from first import ones
from Third import sree
from Fours import Fose
from Seco import twos 
from Bul1 import glass1
from Bul2 import glass2
from Bul3 import glass3
from Bul4 import glass4





open_menu = False # 업그레이드 1(골드벌이)
select = False  # 컨텐츠 선택창
oepn = False
select_m = False
earn_gold = 30
x = 145
y = 260
gob = 0.1
level = 1
use_gold = 200
running = True
hang =[range(1,20)]
Bol1 = True
Bol2 = False
Bol3 = False
Bol4 = False


canvas_width = 400
canvas_height = 350

def enter():
    gfw.World.init(['Thr','doo', 'AAr', 'Oneser', 'tto','Galss','Galss2','Galss3','Galss4', 'nF'])
    global Weap
    Weap = Ax()
    gfw.World.add(gfw.layer.AAr, Weap)

    global OORs
    OORs = twos()
    gfw.World.add(gfw.layer.tto, OORs)

    global OOR
    OOR = ones()
    gfw.World.add(gfw.layer.Oneser, OOR)

    global TThe
    TThe = sree()
    gfw.World.add(gfw.layer.Thr, TThe)

    global Fope
    Fope = Fose()
    gfw.World.add(gfw.layer.nF, Fope)

    global Cho1 # 풀때기
    Cho1 = glass1()
    gfw.World.add(gfw.layer.Galss, Cho1)
    
    global Cho2
    Cho2 = glass2()
    gfw.World.add(gfw.layer.Galss2, Cho2)

    global Cho3
    Cho3 = glass3()
    gfw.World.add(gfw.layer.Galss3, Cho3)

    global Cho4
    Cho4 = glass4()
    gfw.World.add(gfw.layer.Galss4, Cho4)

    global Gold
    Gold = moneys(700, 500)


    global image
    image = load_image('res/광산.png')

    global clicks
    clicks = load_wav(('res/button-28.wav'))

    global bg_musics
    bg_musics = load_music(('res/운동회.mp3'))
    bg_musics.set_volume(55)
    bg_musics.repeat_play()

    global font
    font = gfw.font.load('res/a아띠.ttf', 20)


    global flip_wav
    flip_wav = load_wav(('res/코인소리.wav'))


    

    



    




def check_enemy(e):
    if gobj.collides_box(player, e):
        print('Player Collision', e)
        e.remove()
        return


def update():
    gfw.World.update()



def draw():
    global Bol1
    global Bol2
    global Bol3
    global Bol4

    
# gobj.draw_collision_box()
    image.draw(400, 300)

    if(Bol1 == True):
      font.draw(120, 125, "%d"%Cho1.hp)
      font.draw(120, 90, "%d"%Cho1.defence)
      font.draw(150, 52, "%d퍼"%Cho1.reduce)
      font.draw(150, 16, "%d"%Cho1.get_gold)
      font.draw(650, 52, "%d"%Cho1.count)
      Cho1.draw()
      OOR.draws()
    elif(Bol2 == True):
      font.draw(120, 125, "%d"%Cho2.hp)
      font.draw(120, 90, "%d"%Cho2.defence)
      font.draw(150, 52, "%d퍼"%Cho2.reduce)
      font.draw(150, 16, "%d"%Cho2.get_gold)
      font.draw(650, 52, "%d"%Cho2.count)
      Cho2.draw()
      OORs.draws()
    if(Bol3 == True):
      font.draw(120, 125, "%d"%Cho3.hp)
      font.draw(120, 90, "%d"%Cho3.defence)
      font.draw(150, 52, "%d퍼"%Cho3.reduce)
      font.draw(150, 16, "%d"%Cho3.get_gold)
      font.draw(650, 52, "%d"%Cho3.count)
      Cho3.draw()
      TThe.draws()
    if(Bol4 == True):
      font.draw(120, 125, "%d"%Cho4.hp)
      font.draw(120, 90, "%d"%Cho4.defence)
      font.draw(150, 52, "%d퍼"%Cho4.reduce)
      font.draw(150, 16, "%d"%Cho4.get_gold)
      font.draw(650, 52, "%d"%Cho4.count)
      Cho4.draw()
      Fope.draws()
      Cho4.times -= gfw.delta_time
      font.draw(350, 110, "남은시간 : %d"%Cho4.times)
      if(Cho4.times <=0):
          Bol4 = False
          Bol3 = True
          Cho4.times = 60



    Weap.draw()
    font.draw(650, 175, "%d"%Game.Aox.Power)
    
    
    

    if(Game.Ja1 == True and Game.Ja2==False):
        font.draw(620, 115, "일반 철")
    elif(Game.Ja2 ==True and Game.Ja3==False):
        font.draw(620, 115, "고급 철")
    elif(Game.Ja3==True):
        font.draw(620, 115, "전설의 강철")

    




def handle_event(e):
    global Bol1
    global Bol2 
    global Bol3 
    global Bol4
    Weap.handle_events()
    if e.type == SDL_QUIT:
        gfw.quit()
    elif (e.type, e.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
        gfw.quit()
    
    if(e.type, e.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
        if(210<Weap.x<240 and 200<Weap.y<230): # 앞으로가기
            if(Bol1==True):
                Bol2 = True
                Bol1 = False
                Cho1.hp = 120
            elif(Bol2 == True and Bol1 ==False):
                Bol2 = False
                Bol3 = True
                Cho2.hp == 3900
            elif(Bol3 ==True and Bol4 ==False):
                Bol3 = False
                Bol4 = True
                Cho3.hp = 25000
            
            clicks.play()
        if(60<Weap.x<90 and 200<Weap.y<230): # 뒤로 가기
            if(Bol4 == True):
                Bol4 = False
                Bol3 = True
                Cho4.hp = 300000
            elif(Bol3==True):
                Bol3 = False
                Bol2 = True
                Cho3.hp = 25000
            elif(Bol2 == True):
                Bol2 = False
                Bol1 = True
                Cho2.hp = 3900

                clicks.play()
        if(690<Weap.x<780 and 530<Weap.y<570):
            clicks.play()
            gfw.pop()
            global bg_music
            bg_music = load_music(('res/428. 변명의 변명.mp3'))
            bg_music.set_volume(55)
            bg_music.repeat_play()
        if(((Cho1.x-240 <Weap.x<Cho1.x and Cho1.y-180<Weap.y<Cho1.y) or (Cho1.x+60<Weap.x<Cho1.x+300 and Cho1.y-180 <Weap.y<Cho1.y)or (Cho1.x+360<Weap.x<Cho1.x+600 and Cho1.y-180<Weap.y<Cho1.y))
          and Bol1 == True):
            if(Cho1.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho1.reduce/100)-Cho1.defence))>0):
                if((Game.Aox.Power)<Cho1.defence):
                    Cho1.hp -= 0.5
                elif((Game.Aox.Power-(Game.Aox.Power*(Cho1.reduce/100)-Cho1.defence))>Cho1.defence):
                    Cho1.hp -= Game.Aox.Power-(Game.Aox.Power*(Cho1.reduce/100))-Cho1.defence
            elif(Cho1.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho1.reduce/100)))<=0):
                Cho1.hp =120
                Game.Gold.don += Cho1.get_gold
                Cho1.count +=1
                Cho1.lucky = random.randint(1,100)
                if(Cho1.lucky <25):
                    print("다량의 장작을 획득하여 ", Cho1.get_gold*15," 골드를 벌었습니다")
                    Game.Gold.don += Cho1.get_gold*15
        if(((Cho2.x-240 <Weap.x<Cho2.x and Cho2.y-180<Weap.y<Cho2.y) or (Cho2.x+60<Weap.x<Cho2.x+300 and Cho2.y-180 <Weap.y<Cho2.y)or (Cho2.x+360<Weap.x<Cho2.x+600 and Cho2.y-180<Weap.y<Cho2.y))
          and Bol2 == True):
            if(Cho2.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho2.reduce/100)-Cho2.defence))>0):
                if((Game.Aox.Power)<Cho2.defence):
                    Cho2.hp -= 0.5
                elif((Game.Aox.Power-(Game.Aox.Power*(Cho2.reduce/100)-Cho2.defence))>Cho2.defence):
                    Cho2.hp -= Game.Aox.Power-(Game.Aox.Power*(Cho2.reduce/100))-Cho2.defence
            elif(Cho2.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho2.reduce/100)))<=0):
                Cho2.hp =3900
                Game.Gold.don += Cho2.get_gold
                Cho2.count +=1
                Cho2.lucky = random.randint(1,100)
                if(Cho2.lucky <16):
                    print("다량의 해바라기 씨앗을 획득하여 ", Cho2.get_gold*12," 골드를 벌었습니다")
                    Game.Gold.don += Cho2.get_gold*15
        if(((Cho3.x-240 <Weap.x<Cho3.x and Cho3.y-180<Weap.y<Cho3.y) or (Cho3.x+60<Weap.x<Cho3.x+300 and Cho3.y-180 <Weap.y<Cho3.y)or (Cho3.x+360<Weap.x<Cho3.x+600 and Cho3.y-180<Weap.y<Cho3.y))
          and Bol3 == True):
            if(Cho3.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho3.reduce/100)-Cho3.defence))>0):
                if((Game.Aox.Power)<Cho3.defence):
                    Cho3.hp -= 0.5
                elif((Game.Aox.Power-(Game.Aox.Power*(Cho3.reduce/100)-Cho3.defence))>Cho3.defence):
                    Cho3.hp -= Game.Aox.Power-(Game.Aox.Power*(Cho3.reduce/100))-Cho3.defence
            elif(Cho3.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho3.reduce/100)))<=0):
                Cho3.hp =25000
                Game.Gold.don += Cho3.get_gold
                Cho3.count +=1
                Cho3.lucky = random.randint(1,100)
                if(Cho3.lucky <10):
                    print("다량의 해바라기 씨앗을 획득하여 ", Cho3.get_gold*15," 골드를 벌었습니다")
                    Game.Gold.don += Cho3.get_gold*15
        if(((Cho4.x-240 <Weap.x<Cho4.x and Cho4.y-180<Weap.y<Cho4.y))and Bol4 == True):
            if(Cho4.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho4.reduce/100)-Cho4.defence))>0):
                if((Game.Aox.Power)<Cho4.defence):
                    Cho4.hp -= 0.5
                elif((Game.Aox.Power-(Game.Aox.Power*(Cho4.reduce/100)-Cho4.defence))>Cho4.defence):
                    Cho4.hp -= Game.Aox.Power-(Game.Aox.Power*(Cho4.reduce/100))-Cho4.defence
            elif(Cho4.hp-(Game.Aox.Power-(Game.Aox.Power*(Cho4.reduce/100)))<=0):
                Cho4.hp =25000
                Game.Gold.don += Cho4.get_gold
                Cho4.count +=1
                Cho4.lucky = random.randint(1,100)
                if(Cho4.lucky <5):
                    print("다량의 해바라기 씨앗을 획득하여 ", Cho4.get_gold*15," 골드를 벌었습니다")
                    Game.Gold.don += Cho4.get_gold*15
                    
                flip_wav.play()
            clicks.play()



def exit():
    global image

    del image



    
if __name__ == '__main__':
    gfw.run_main()

def pause():
    pass
def resume():
    pass