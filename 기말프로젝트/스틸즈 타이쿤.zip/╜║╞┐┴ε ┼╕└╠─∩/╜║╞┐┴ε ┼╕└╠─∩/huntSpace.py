import gfw
from pico2d import *
import Title
import random
import World
import gobj
import font
import Start
import gold
import choice
import Game
from Weapon import Weapons
from moru import morus
from map import maps
from UI import UIS
from gold import moneys
from menuchang import ME
from interface import inter
from content import MA
from sel import MAd
from tool_up import Uper
from Axe import Ax
from F import fishing
from moru_up1 import morus1
from moru_up2 import morus2
from Mate import Yes
from Level1 import ducks
from Bow import Arrows
from first import ones
from Third import sree
from Fours import Fose
from Seco import twos 
from LV_2 import  horse
from LV3 import Goms
from LV4 import Boss

open_menu = False # 업그레이드 1(골드벌이)
select = False  # 컨텐츠 선택창
oepn = False
select_m = False
earn_gold = 30

gob = 0.1
level = 1
use_gold = 200
running = True
hang =[range(1,20)]
Oris = True
Hose = False
Ges = False
FOSE = False

canvas_width = 400
canvas_height = 350

def enter():
    gfw.World.init(['horses','Beer',  'Thr','doo', 'AAr', 'Oneser', 'tto' , 'Loin','nF'])
    global Weap
    Weap = Arrows()
    gfw.World.add(gfw.layer.AAr, Weap)

    global Ori
    Ori = ducks()
    gfw.World.add(gfw.layer.doo, Ori)

    global Ho
    Ho = horse()
    gfw.World.add(gfw.layer.horses, Ho)

    global OORs
    OORs = twos()
    gfw.World.add(gfw.layer.tto, OORs)

    global OOR
    OOR = ones()
    gfw.World.add(gfw.layer.Oneser, OOR)

    global DDDS
    DDDS = Goms()
    gfw.World.add(gfw.layer.Beer, DDDS)

    global TThe
    TThe = sree()
    gfw.World.add(gfw.layer.Thr, TThe)

    global Fope
    Fope = Fose()
    gfw.World.add(gfw.layer.nF, Fope)

    global Jang
    Jang = Boss()
    gfw.World.add(gfw.layer.Loin, Jang)


    global Gold
    Gold = moneys(700, 500)


    global image
    image = load_image('res/사냥.png')

    global clicks
    clicks = load_wav(('res/button-28.wav'))

    global bg_musics
    bg_musics = load_music(('res/운동회.mp3'))
    bg_musics.set_volume(55)
    bg_musics.repeat_play()

    global font
    font = gfw.font.load('res/a아띠.ttf', 20)


    global flip_wav
    flip_wav = load_wav(('res/코인소리.wav'))


    

    



    




def check_enemy(e):
    if gobj.collides_box(player, e):
        print('Player Collision', e)
        e.remove()
        return


def update():
    gfw.World.update()



def draw():
    global Ori
    global Ges
    global FOSE
# gobj.draw_collision_box()
    image.draw(400, 300)
    Weap.draw()

    if(Oris == True):
      font.draw(120, 165, "%d"%Ori.hp)
      font.draw(120, 130, "%d"%Ori.defence)
      font.draw(150, 92, "%d퍼"%Ori.reduce)
      font.draw(150, 56, "%d"%Ori.get_gold)
      font.draw(650, 92, "%d"%Ori.count)
      Ori.draw()
      OOR.draw()
    if(Hose == True):
      font.draw(120, 165, "%d"%Ho.hp)
      font.draw(120, 130, "%d"%Ho.defence)
      font.draw(150, 92, "%d퍼"%Ho.reduce)
      font.draw(150, 56, "%d"%Ho.get_gold)
      font.draw(650, 92, "%d"%Ho.count)
      Ho.draw()
      OORs.draw()
    if(Ges == True):
      font.draw(120, 165, "%d"%DDDS.hp)
      font.draw(120, 130, "%d"%DDDS.defence)
      font.draw(150, 92, "%d퍼"%DDDS.reduce)
      font.draw(150, 56, "%d"%DDDS.get_gold)
      font.draw(650, 92, "%d"%DDDS.count)
      DDDS.draw()
      TThe.draw()
    if(FOSE == True):
      font.draw(120, 165, "%d"%Jang.hp)
      font.draw(120, 130, "%d"%Jang.defence)
      font.draw(150, 92, "%d퍼"%Jang.reduce)
      font.draw(150, 56, "%d"%Jang.get_gold)
      font.draw(650, 92, "%d"%Jang.count)
      Jang.draw()
      Fope.draw()
      Jang.times -= gfw.delta_time
      font.draw(350, 150, "남은시간 : %d"%Jang.times)
      if(Jang.times <=0):
          FOSE = False
          Ges = True
          Jang.times = 60



    font.draw(650, 215, "%d"%Game.Aro.Power)
    
    
    

    if(Game.Ja1 == True and Game.Ja2==False):
        font.draw(620, 155, "일반 철")
    elif(Game.Ja2 ==True and Game.Ja3==False):
        font.draw(620, 155, "고급 철")
    elif(Game.Ja3==True):
        font.draw(620, 155, "전설의 강철")

    




def handle_event(e):
    global Weap
    global Game
    global Oris
    global Hose
    global Ges
    global FOSE
    Weap.handle_events()
    if e.type == SDL_QUIT:
        gfw.quit()
    elif (e.type, e.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
        gfw.quit()
    
    if(e.type, e.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
        if(210<Weap.x<240 and 240<Weap.y<270):
            if(Oris == True):
                Oris=False
                Ori.hp = 400
                Hose = True
            elif(Hose == True):
                Hose =False
                Ges = True
            elif(Ges == True):
                Ges = False
                FOSE = True
            clicks.play()
        if(60<Weap.x<90 and 240<Weap.y<270):
            if(FOSE == True):
                FOSE = False
                Jang.times = 60
                Jang.hp = 6000000
                Ges = True
            elif(Ges == True):
                Ges = False
                DDDS.hp = 1200000
                Hose = True
            elif(Hose == True):
                Hose =False
                Ho.hp = 99000
                Oris = True
            clicks.play()

        if(690<Weap.x<780 and 530<Weap.y<570):
            clicks.play()
            gfw.pop()
            Oris = True
            Hose = False
            Ges = False
            FOSE = False
            global bg_music
            bg_music = load_music(('res/428. 변명의 변명.mp3'))
            bg_music.set_volume(55)
            bg_music.repeat_play()
        if(Ori.x-180 <Weap.x<Ori.x and Ori.y-180<Weap.y<Ori.y and Oris == True):
            if(Ori.hp-(Game.Aro.Power-(Game.Aro.Power*(Ori.reduce/100)-Ori.defence))>0):
                if((Game.Aro.Power)<Ori.defence):
                    Ori.hp -= 0.5
                elif((Game.Aro.Power-(Game.Aro.Power*(Ori.reduce/100)-Ori.defence))>Ori.defence):
                    Ori.hp -= Game.Aro.Power-(Game.Aro.Power*(Ori.reduce/100))-Ori.defence
            elif(Ori.hp-(Game.Aro.Power-(Game.Aro.Power*(Ori.reduce/100)))<=0):
                Ori.hp =400
                Game.Gold.don += Ori.get_gold
                Ori.count +=1
                Ori.lucky = random.randint(1,100)
                if(Ori.lucky <15):
                    print("오리의 알을 발견하여", Ori.get_gold*15," 골드를 벌었습니다")
                    Game.Gold.don += Ori.get_gold*15
                    
                flip_wav.play()
            clicks.play()
        if(Ho.x-180 <Weap.x<Ho.x and Ho.y-180<Weap.y<Ho.y and Hose == True):
            if(Ho.hp-(Game.Aro.Power-(Game.Aro.Power*(Ho.reduce/100)-Ho.defence))>0):
                if((Game.Aro.Power)<Ho.defence):
                    Ho.hp -= 0.5
                elif((Game.Aro.Power-(Game.Aro.Power*(Ho.reduce/100)-Ho.defence))>Ho.defence):
                    Ho.hp -= Game.Aro.Power-(Game.Aro.Power*(Ho.reduce/100))-Ho.defence
            elif(Ho.hp-(Game.Aro.Power-(Game.Aro.Power*(Ho.reduce/100)))<=0):
                Ho.hp = 99000
                Game.Gold.don += Ho.get_gold
                Ho.count +=1
                Ho.lucky = random.randint(1,100)
                if(Ho.lucky <7):
                    print("고급 말고기를 채집하여", Ho.get_gold*18," 골드를 벌었습니다")
                    Game.Gold.don += Ho.get_gold*18
                flip_wav.play()
            clicks.play()
        if(DDDS.x-180 <Weap.x<DDDS.x and DDDS.y-180<Weap.y<DDDS.y and Ges == True):
            if(DDDS.hp-(Game.Aro.Power-(Game.Aro.Power*(DDDS.reduce/100)-DDDS.defence))>0):
                if((Game.Aro.Power)<DDDS.defence):
                    DDDS.hp -= 0.5
                elif((Game.Aro.Power-(Game.Aro.Power*(DDDS.reduce/100)-DDDS.defence))>DDDS.defence):
                    DDDS.hp -= Game.Aro.Power-(Game.Aro.Power*(DDDS.reduce/100))-DDDS.defence
            elif(DDDS.hp-(Game.Aro.Power-(Game.Aro.Power*(DDDS.reduce/100)))<=0):
                DDDS.hp = 1200000
                Game.Gold.don += DDDS.get_gold
                DDDS.count +=1
                DDDS.lucky = random.randint(1,100)
                if(Ho.lucky <3):
                    print("고급 웅담을 채집하여", DDDS.get_gold*18," 골드를 벌었습니다")
                    Game.Gold.don += DDDS.get_gold*18
                flip_wav.play()
            clicks.play()
        if(Jang.x-180 <Weap.x<Jang.x and Jang.y-180<Weap.y<Jang.y and FOSE == True):
            if(Jang.hp-(Game.Aro.Power-(Game.Aro.Power*(Jang.reduce/100)-Jang.defence))>0):
                if((Game.Aro.Power)<Jang.defence):
                    Jang.hp -= 0.5
                elif((Game.Aro.Power-(Game.Aro.Power*(Jang.reduce/100)-Jang.defence))>Jang.defence):
                    Jang.hp -= Game.Aro.Power-(Game.Aro.Power*(Jang.reduce/100))-Jang.defence
            elif(Jang.hp-(Game.Aro.Power-(Game.Aro.Power*(Jang.reduce/100)))<=0):
                Jang.hp = 6000000
                Game.Gold.don += Jang.get_gold
                Jang.count +=1
                Jang.lucky = random.randint(1,100)
                if(Jang.lucky <1):
                    print("사자갈기를 채집하여", Jang.get_gold*18," 골드를 벌었습니다")
                    Game.Gold.don += Jang.get_gold*18
                flip_wav.play()


def exit():
    global image

    del image



    
if __name__ == '__main__':
    gfw.run_main()

def pause():
    pass
def resume():
    pass