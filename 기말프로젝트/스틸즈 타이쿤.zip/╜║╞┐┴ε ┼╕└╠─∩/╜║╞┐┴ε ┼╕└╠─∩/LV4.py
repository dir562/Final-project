
from pico2d import*
import os
import Game
import gfw_image
import gfw
import Title
import random
from gold import moneys
from moru import morus


Chajip = False



height = 600
width = 800

def enter():
    global Gold
    Gold = moneys()
    Gold.init()

class Boss:
    def __init__(self):
        self.lucky = random.randint(1,100)
        self.lx = 400
        self.ly =230
        self.x = 10
        self.y = 500
        self.frame =2
        self.hp = 6000000
        self.get_gold = 3000000
        self.reduce = 70
        self.count = 0
        self.defence = 8000
        self.times = 60 
        self.dx =1
        self.fride = 180
        Boss.images = None
        Boss.ima =None
        Boss.imat = None
        if Boss.images == None:
            Boss.images = gfw_image.load("res/사자1.png")
        if Boss.ima == None:
            Boss.ima = gfw_image.load("res/사자2.png")
        if Boss.imat == None:
            Boss.imat = gfw_image.load("res/사자3.png")
    def update(self):
        self.x +=4*self.dx
        if(self.x>800):
            self.dx =-1
        elif(self.x<0):
            self.dx = 1
        pass
    def draw(self):
        if(self.dx == -1):
            self.ima.draw(self.x, self.y)
        elif(self.dx ==1):
            self.images.draw(self.x, self.y)

        self.imat.draw(self.lx, self.ly)
        self.update()
    def handle_events(self):
        global Gold
        global running
        hide_cursor()
        events = get_events()
        for event in events:
           if event.type == SDL_MOUSEMOTION:
              self.x,self.y = event.x,height - 1 -event.y
           if event.type == SDL_MOUSEBUTTONDOWN:
               if event.button == SDL_BUTTON_LEFT:
                   pass
           if event.type == SDL_MOUSEBUTTONUP:
               if event.button == SDL_BUTTON_LEFT:
                   pass


    
 

