import gfw_image
import Game
import gfw
import os
import World




class inter:
    def __init__(self):
        self.x = 400
        self.y = 200
        self.image = gfw.gfw_image.load("res/강화 인터페이스.png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def update(self):
        pass

