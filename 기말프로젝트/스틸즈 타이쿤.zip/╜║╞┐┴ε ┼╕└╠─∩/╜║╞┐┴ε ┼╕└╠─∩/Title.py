
import gfw
from pico2d import *
import Game
from Weapon import Weapons
import os



def enter():
    global image
    image = load_image('res/main_title_steel.png')


    global bg_music
    bg_music = load_music(('res/428. 변명의 변명.mp3'))
    bg_music.set_volume(55)
    bg_music.repeat_play()


def update():
    pass

def draw():
    image.draw(400, 300)

def handle_event(e):
    if e.type == SDL_QUIT:
        gfw.quit()
    elif (e.type, e.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
        gfw.quit()
    elif (e.type, e.key) ==(SDL_KEYDOWN, SDLK_SPACE):
        gfw.push(Game)

def exit():
    global image
    del image

def pause():
    pass
def resume():
    pass
    
if __name__ == '__main__':
    gfw.run_main()
