from pico2d import*
import gfw
import Title

gfw.run(title_state)