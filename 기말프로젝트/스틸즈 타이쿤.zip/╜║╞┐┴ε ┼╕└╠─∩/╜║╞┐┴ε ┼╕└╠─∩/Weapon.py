from pico2d import*
import os
import Game
import gfw_image
import gfw
import Title
from gold import moneys
from moru import morus


Chajip = False



height = 600
width = 800

def enter():
    global Gold
    Gold = moneys()
    Gold.init()

class Weapons:
    def __init__(self):
        self.x =width
        self.y = height
        self.frame = 1
        self.dx = 1
        self.dy = 1
        self.pos = 200
        self.hpos = 200
        Weapons.images = None
        if Weapons.images == None:
            Weapons.images = gfw_image.load("res/ball41x41.png")
    def update(self):
        pass
    def draw(self):
        self.images.draw(self.x, self.y)
        self.update()
    def handle_events(self):
        global Gold
        global running
        hide_cursor()
        events = get_events()
        for event in events:
           if event.type == SDL_MOUSEMOTION:
              self.x,self.y = event.x,height - 1 -event.y
           if event.type == SDL_MOUSEBUTTONDOWN:
               if event.button == SDL_BUTTON_LEFT:
                   pass
           if event.type == SDL_MOUSEBUTTONUP:
               if event.button == SDL_BUTTON_LEFT:
                   pass


    
 





