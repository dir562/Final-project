
from pico2d import*
import os
import Game
import gfw_image
import gfw



class morus1:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.fram = 1
        self.cost = 1000000
        self.upgrader = 1.2
        self.upgra = 20
        morus1.images = None
        if morus1.images == None:
            morus1.images = gfw_image.load("res/모루 강화.png")
    def update(self):
        pass
    def draw(self):
        self.images.draw(self.x, self.y)
        self.update()

  


