

from pico2d import*
import os
import Game
import gfw_image
import gfw



class morus2:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.fram = 1
        self.cost = 30000000
        self.upgrader = 1.5
        self.upgra = 50
        morus2.images = None
        if morus2.images == None:
            morus2.images = gfw_image.load("res/모루 강화2.png")
    def update(self):
        pass
    def draw(self):
        self.images.draw(self.x, self.y)
        self.update()

  


