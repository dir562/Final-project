import gfw_image
import Game
import gfw
import os
import World




class ME:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = gfw.gfw_image.load("res/메뉴창(400400).png")
    def draw(self):
        self.image.draw(self.x, self.y)
    def update(self):
        pass
