

from pico2d import*
import os
import Game
import gfw_image
import gfw
import Title
from gold import moneys
import random
from moru import morus


Chajip = False



height = 600
width = 800

def enter():
    global Gold
    Gold = moneys()
    Gold.init()

class glass2:
    def __init__(self):
        self.lucky = (random.randint(1,100))
        self.lx = 400
        self.ly =190
        self.x = 100
        self.y = 400
        self.frame =2
        self.hp = 3900
        self.get_gold = 770
        self.reduce = 6
        self.count = 0
        self.defence = 20
        self.dx =1
        self.fride = 180
        glass2.images = None
        if glass2.images == None:
            glass2.images = gfw_image.load("res/벌목2.png")
        glass2.ima = None
        if glass2.ima ==None:
            glass2.ima = gfw_image.load("res/벌목2-1.png")
    def update(self):
        if(self.x>800):
            self.dx =-1
        elif(self.x<0):
            self.dx = 1
        pass
    def draw(self):
        self.images.draw(self.x, self.y)
        self.images.draw(self.x+300, self.y)
        self.images.draw(self.x+600, self.y)
        self.ima.draw(self.lx, self.ly)
        self.update()
    def handle_events(self):
        global Gold
        global running
        hide_cursor()
        events = get_events()
        for event in events:
           if event.type == SDL_MOUSEMOTION:
              self.x,self.y = event.x,height - 1 -event.y
           if event.type == SDL_MOUSEBUTTONDOWN:
               if event.button == SDL_BUTTON_LEFT:
                   pass
           if event.type == SDL_MOUSEBUTTONUP:
               if event.button == SDL_BUTTON_LEFT:
                   pass


    
 
