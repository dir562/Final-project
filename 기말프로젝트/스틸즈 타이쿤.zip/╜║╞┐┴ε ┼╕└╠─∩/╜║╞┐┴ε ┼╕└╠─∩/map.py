from pico2d import*
import os
import Game
import gfw_image



class maps:
    def __init__(self):
        self.x = 0
        self.y = 200
        maps.image = None
        if maps.image == None:
            maps.image =gfw_image.load("res/space.png")
        self.fram = 1
    def draw(self):
        self.image.draw(self.x, self.y)
   #     self.image.draw(self.x+250, self.y)
     #   self.image.draw(self.x+500, self.y)
      #  self.image.draw(self.x+750, self.y)
        self.update()
    def update(self):
        pass
  
